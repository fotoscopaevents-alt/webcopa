import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ExperienceSection } from "@/components/experience-section"
import { ImpactSection } from "@/components/impact-section"
import { EventsSection } from "@/components/events-section"
import { ContentSection } from "@/components/content-section"
import { SponsorsSection } from "@/components/sponsors-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ExperienceSection />
      <ImpactSection />
      <EventsSection />
      <ContentSection />
      <SponsorsSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
