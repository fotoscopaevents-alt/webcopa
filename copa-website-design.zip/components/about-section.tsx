"use client"

import { motion } from "framer-motion"

export function AboutSection() {
  return (
    <section id="nosotros" className="relative py-32 md:py-48 overflow-hidden">
      <div className="absolute inset-0 bg-background" />

      {/* Decorative line */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-12 gap-16 items-start">
          {/* Left - Label */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-3"
          >
            <span className="text-primary font-medium tracking-widest text-sm">QUIENES SOMOS</span>
            <div className="w-16 h-px bg-primary mt-4" />
          </motion.div>

          {/* Right - Content */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-9"
          >
            <h2 className="font-[var(--font-display)] text-5xl md:text-7xl lg:text-8xl tracking-tight mb-8 leading-[0.9]">
              NO ORGANIZAMOS
              <br />
              <span className="text-primary">TORNEOS.</span>
            </h2>

            <p className="font-[var(--font-display)] text-3xl md:text-4xl lg:text-5xl tracking-tight text-muted-foreground mb-12 leading-tight">
              CREAMOS EXPERIENCIAS.
            </p>

            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <p className="text-lg text-muted-foreground leading-relaxed">
                COPA nacio con una idea simple: el deporte es mas que competicion. Es cultura. Comunidad. Identidad. 
                Cada evento que creamos esta disenado para unir personas, crear recuerdos y construir algo mas grande que el partido en si.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Somos una marca de cultura deportiva, una empresa de eventos, una comunidad juvenil. 
                Transformamos el futbol amateur en experiencias premium que nadie olvida.
              </p>
            </div>

            {/* Manifesto Quote */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.4 }}
              className="border-l-4 border-primary pl-8"
            >
              <p className="font-[var(--font-display)] text-2xl md:text-3xl tracking-tight text-foreground">
                &ldquo;EL FUTBOL ES SOLO LA EXCUSA. EL VERDADERO JUEGO ES LA VIDA.&rdquo;
              </p>
              <span className="text-sm text-muted-foreground mt-4 block tracking-widest">— MANIFIESTO COPA</span>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
