"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowRight, Check } from "lucide-react"

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    type: "",
    message: "",
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="contacto" className="relative py-32 md:py-48 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-card" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left - Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary font-medium tracking-widest text-sm">CONTACTO</span>
            <h2 className="font-[var(--font-display)] text-5xl md:text-7xl lg:text-8xl tracking-tight mt-4 mb-8 leading-[0.9]">
              HABLEMOS DE
              <br />
              <span className="text-primary">FUTURO</span>
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-12 max-w-md">
              Buscamos marcas, colaboradores y partners que quieran formar parte de algo grande. 
              Si compartes nuestra vision, queremos conocerte.
            </p>

            {/* Contact types */}
            <div className="space-y-6">
              {[
                { title: "PARTNERSHIPS", desc: "Colaboraciones estrategicas con marcas" },
                { title: "SPONSORS", desc: "Oportunidades de patrocinio y visibilidad" },
                { title: "MEDIA", desc: "Prensa, entrevistas y colaboraciones" },
                { title: "GENERAL", desc: "Otras consultas y propuestas" },
              ].map((item) => (
                <div key={item.title} className="group flex items-start gap-4">
                  <div className="w-2 h-2 bg-primary mt-2 group-hover:scale-150 transition-transform" />
                  <div>
                    <h4 className="font-[var(--font-display)] text-lg tracking-wide group-hover:text-primary transition-colors">
                      {item.title}
                    </h4>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right - Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {submitted ? (
              <div className="bg-background border border-primary p-12 text-center">
                <div className="w-20 h-20 rounded-full bg-primary flex items-center justify-center mx-auto mb-6">
                  <Check className="w-10 h-10 text-primary-foreground" />
                </div>
                <h3 className="font-[var(--font-display)] text-4xl tracking-tight mb-4">MENSAJE ENVIADO</h3>
                <p className="text-muted-foreground">
                  Gracias por tu interes. Nos pondremos en contacto contigo lo antes posible.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-background border border-border p-8 md:p-12">
                <h3 className="font-[var(--font-display)] text-3xl tracking-tight mb-8">ENVIAR MENSAJE</h3>

                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm text-muted-foreground mb-2 tracking-wide">
                        NOMBRE
                      </label>
                      <input
                        type="text"
                        id="name"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                        placeholder="Tu nombre"
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm text-muted-foreground mb-2 tracking-wide">
                        EMAIL
                      </label>
                      <input
                        type="email"
                        id="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                        placeholder="tu@email.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-sm text-muted-foreground mb-2 tracking-wide">
                      EMPRESA / ORGANIZACION
                    </label>
                    <input
                      type="text"
                      id="company"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full px-4 py-3 bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                      placeholder="Nombre de tu empresa"
                    />
                  </div>

                  <div>
                    <label htmlFor="type" className="block text-sm text-muted-foreground mb-2 tracking-wide">
                      TIPO DE CONSULTA
                    </label>
                    <select
                      id="type"
                      required
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                      className="w-full px-4 py-3 bg-secondary border border-border text-foreground focus:outline-none focus:border-primary transition-colors appearance-none cursor-pointer"
                    >
                      <option value="">Selecciona una opcion</option>
                      <option value="partnership">Partnership</option>
                      <option value="sponsor">Patrocinio</option>
                      <option value="media">Prensa / Media</option>
                      <option value="general">Consulta general</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm text-muted-foreground mb-2 tracking-wide">
                      MENSAJE
                    </label>
                    <textarea
                      id="message"
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none"
                      placeholder="Cuentanos sobre tu propuesta..."
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="group w-full mt-8 px-8 py-4 bg-primary text-primary-foreground font-[var(--font-display)] text-xl tracking-wide flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors"
                >
                  ENVIAR
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
