"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Play, ArrowUpRight, Instagram } from "lucide-react"

const contentItems = [
  { id: 1, type: "video", tag: "AFTERMOVIE", title: "Copa Resacon 2024" },
  { id: 2, type: "image", tag: "BEHIND THE SCENES", title: "El equipo detras" },
  { id: 3, type: "video", tag: "HIGHLIGHTS", title: "Mejores momentos" },
  { id: 4, type: "image", tag: "COMUNIDAD", title: "La familia COPA" },
  { id: 5, type: "video", tag: "AFTERPARTY", title: "Cuando cae el sol" },
  { id: 6, type: "image", tag: "CULTURA", title: "Mas que futbol" },
]

export function ContentSection() {
  const [hoveredId, setHoveredId] = useState<number | null>(null)

  return (
    <section id="contenido" className="relative py-32 md:py-48 overflow-hidden">
      <div className="absolute inset-0 bg-background" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-16 gap-6"
        >
          <div>
            <span className="text-primary font-medium tracking-widest text-sm">CONTENIDO</span>
            <h2 className="font-[var(--font-display)] text-5xl md:text-7xl tracking-tight mt-4 leading-[0.9]">
              MOMENTOS
              <br />
              <span className="text-primary">QUE INSPIRAN</span>
            </h2>
          </div>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 font-[var(--font-display)] text-lg tracking-wide text-muted-foreground hover:text-primary transition-colors"
          >
            <Instagram className="w-5 h-5" />
            SEGUIR EN INSTAGRAM
            <ArrowUpRight className="w-5 h-5" />
          </a>
        </motion.div>

        {/* Content Grid - Magazine Style */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {contentItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`group relative overflow-hidden cursor-pointer ${
                index === 0 ? "md:col-span-2 md:row-span-2 aspect-square md:aspect-auto" : "aspect-square"
              }`}
              onMouseEnter={() => setHoveredId(item.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-secondary via-card to-secondary">
                <div className="absolute inset-0 opacity-50">
                  <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_40%,rgba(255,230,0,0.1)_50%,transparent_60%)]" />
                </div>
              </div>

              {/* Hover overlay */}
              <div
                className={`absolute inset-0 bg-primary/90 transition-opacity duration-300 ${
                  hoveredId === item.id ? "opacity-100" : "opacity-0"
                }`}
              />

              {/* Content */}
              <div className="absolute inset-0 p-4 md:p-6 flex flex-col justify-between">
                {/* Tag */}
                <span
                  className={`inline-block self-start px-3 py-1 text-xs font-medium tracking-wide border transition-colors ${
                    hoveredId === item.id
                      ? "text-primary-foreground border-primary-foreground/30"
                      : "text-foreground border-border"
                  }`}
                >
                  {item.tag}
                </span>

                {/* Play icon for videos */}
                {item.type === "video" && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div
                      className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                        hoveredId === item.id ? "bg-primary-foreground scale-110" : "bg-white/20"
                      }`}
                    >
                      <Play
                        className={`w-6 h-6 fill-current ml-1 ${
                          hoveredId === item.id ? "text-primary" : "text-white"
                        }`}
                      />
                    </div>
                  </div>
                )}

                {/* Title */}
                <div
                  className={`transition-all duration-300 ${
                    hoveredId === item.id ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                  }`}
                >
                  <h3 className="font-[var(--font-display)] text-xl md:text-2xl text-primary-foreground">
                    {item.title}
                  </h3>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
