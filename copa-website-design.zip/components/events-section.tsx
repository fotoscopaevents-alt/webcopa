"use client"

import { motion } from "framer-motion"
import { Play } from "lucide-react"

const events = [
  {
    id: "resacon",
    title: "COPA RESACON",
    subtitle: "La leyenda continua",
    description: "El torneo mas iconico del futbol amateur. Donde nacen las historias.",
    date: "PRIMAVERA 2025",
  },
  {
    id: "colegial",
    title: "COPA COLEGIAL",
    subtitle: "El clasico universitario",
    description: "Las mejores universidades compitiendo por la gloria. Representa a los tuyos.",
    date: "OTONO 2025",
  },
  {
    id: "padel",
    title: "COPA PADEL",
    subtitle: "La nueva ola",
    description: "El padel mas premium con afterparty incluida. Una experiencia completa.",
    date: "VERANO 2025",
  },
]

export function EventsSection() {
  return (
    <section id="eventos" className="relative py-32 md:py-48 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-card" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <span className="text-primary font-medium tracking-widest text-sm">PROXIMOS EVENTOS</span>
          <h2 className="font-[var(--font-display)] text-5xl md:text-7xl lg:text-8xl tracking-tight mt-4 leading-[0.9]">
            EXPERIENCIAS
            <br />
            <span className="text-primary">2025</span>
          </h2>
        </motion.div>

        {/* Events - Editorial Style */}
        <div className="space-y-0">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group border-t border-border py-12 md:py-16 cursor-pointer hover:bg-secondary/30 transition-colors -mx-6 px-6"
            >
              <div className="grid md:grid-cols-12 gap-8 items-center">
                {/* Number */}
                <div className="md:col-span-1 hidden md:block">
                  <span className="font-[var(--font-display)] text-4xl text-primary/30 group-hover:text-primary transition-colors">
                    0{index + 1}
                  </span>
                </div>

                {/* Title */}
                <div className="md:col-span-5">
                  <span className="text-sm text-muted-foreground tracking-widest block mb-2">{event.subtitle}</span>
                  <h3 className="font-[var(--font-display)] text-4xl md:text-5xl lg:text-6xl tracking-tight group-hover:text-primary transition-colors">
                    {event.title}
                  </h3>
                </div>

                {/* Description */}
                <div className="md:col-span-4">
                  <p className="text-muted-foreground">{event.description}</p>
                </div>

                {/* Date & CTA */}
                <div className="md:col-span-2 flex items-center justify-between md:justify-end gap-4">
                  <span className="font-[var(--font-display)] text-sm tracking-widest text-primary">{event.date}</span>
                  <div className="w-12 h-12 rounded-full border border-border flex items-center justify-center group-hover:border-primary group-hover:bg-primary transition-all">
                    <Play className="w-5 h-5 text-muted-foreground group-hover:text-primary-foreground ml-0.5 transition-colors" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <p className="text-muted-foreground mb-4">Quieres estar al dia de todos nuestros eventos?</p>
          <a
            href="#contacto"
            className="inline-block px-8 py-4 bg-primary text-primary-foreground font-[var(--font-display)] text-xl tracking-wide hover:bg-primary/90 transition-colors"
          >
            MANTENTE INFORMADO
          </a>
        </motion.div>
      </div>
    </section>
  )
}
