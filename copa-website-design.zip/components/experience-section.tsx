"use client"

import { motion } from "framer-motion"
import { Play } from "lucide-react"

export function ExperienceSection() {
  return (
    <section id="experiencia" className="relative py-32 md:py-48 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-background" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-24"
        >
          <span className="text-primary font-medium tracking-widest text-sm">LA EXPERIENCIA</span>
          <h2 className="font-[var(--font-display)] text-5xl md:text-7xl lg:text-8xl tracking-tight mt-4 leading-[0.9]">
            MAS QUE
            <br />
            <span className="text-primary">PARTIDOS</span>
          </h2>
        </motion.div>

        {/* Cinematic Grid */}
        <div className="grid lg:grid-cols-2 gap-6 md:gap-8">
          {/* Large Video Card */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="group relative aspect-[4/3] lg:aspect-auto lg:row-span-2 overflow-hidden cursor-pointer"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 via-zinc-800 to-black">
              <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,230,0,0.05)_50%,transparent_75%)]" />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            
            {/* Play Button */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-24 h-24 rounded-full bg-primary/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-primary/40 group-hover:scale-110 transition-all duration-300">
                <Play className="w-10 h-10 text-primary fill-primary ml-1" />
              </div>
            </div>

            {/* Content */}
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <span className="text-primary text-sm tracking-widest">AFTERMOVIE 2024</span>
              <h3 className="font-[var(--font-display)] text-4xl md:text-5xl tracking-tight mt-2 text-foreground">
                REVIVE LA EXPERIENCIA
              </h3>
            </div>
          </motion.div>

          {/* Top Right Card */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="group relative aspect-[16/9] overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-zinc-900 to-black" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            
            <div className="absolute inset-0 p-8 flex flex-col justify-end">
              <span className="text-primary text-sm tracking-widest">AFTERPARTY</span>
              <h3 className="font-[var(--font-display)] text-3xl md:text-4xl tracking-tight mt-2 text-foreground">
                DONDE EL PARTIDO CONTINUA
              </h3>
              <p className="text-muted-foreground mt-2 text-sm max-w-sm">
                Cada torneo termina con una celebracion. DJs en vivo, bebidas premium y la energia que solo COPA puede crear.
              </p>
            </div>
          </motion.div>

          {/* Bottom Right Card */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="group relative aspect-[16/9] overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-zinc-800 via-zinc-900 to-black" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            
            <div className="absolute inset-0 p-8 flex flex-col justify-end">
              <span className="text-primary text-sm tracking-widest">COMUNIDAD</span>
              <h3 className="font-[var(--font-display)] text-3xl md:text-4xl tracking-tight mt-2 text-foreground">
                DONDE NACE LA CONEXION
              </h3>
              <p className="text-muted-foreground mt-2 text-sm max-w-sm">
                Mas de 50,000 personas ya forman parte de la comunidad COPA. Encuentros, networking y amistades que duran.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Experience Features */}
        <div className="grid md:grid-cols-4 gap-8 mt-24">
          {[
            { number: "01", title: "AFTERPARTY", desc: "Celebracion despues de cada evento" },
            { number: "02", title: "VIP EXPERIENCE", desc: "Mesas premium y servicio exclusivo" },
            { number: "03", title: "LIVE DJS", desc: "Los mejores artistas de la escena" },
            { number: "04", title: "CONTENT", desc: "Creacion de momentos inolvidables" },
          ].map((item, index) => (
            <motion.div
              key={item.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="group"
            >
              <span className="font-[var(--font-display)] text-6xl text-primary/20 group-hover:text-primary/40 transition-colors">
                {item.number}
              </span>
              <h4 className="font-[var(--font-display)] text-xl tracking-tight mt-2 group-hover:text-primary transition-colors">
                {item.title}
              </h4>
              <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
