"use client"

import { motion } from "framer-motion"
import { Instagram, Youtube } from "lucide-react"
import Link from "next/link"

const socialLinks = [
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Youtube, href: "#", label: "YouTube" },
]

const footerLinks = [
  {
    title: "EVENTOS",
    links: [
      { label: "Copa Resacon", href: "#" },
      { label: "Copa Colegial", href: "#" },
      { label: "Copa Padel", href: "#" },
    ],
  },
  {
    title: "EMPRESA",
    links: [
      { label: "Quienes Somos", href: "#nosotros" },
      { label: "Partners", href: "#" },
      { label: "Contacto", href: "#contacto" },
    ],
  },
  {
    title: "LEGAL",
    links: [
      { label: "Politica de Privacidad", href: "#" },
      { label: "Terminos de Uso", href: "#" },
      { label: "Cookies", href: "#" },
    ],
  },
]

export function Footer() {
  return (
    <footer className="relative py-16 md:py-24 overflow-hidden">
      <div className="absolute inset-0 bg-background" />
      <div className="absolute top-0 left-0 w-full h-px bg-border" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="font-[var(--font-display)] text-5xl tracking-tight text-primary">
              COPA
            </Link>
            <p className="text-muted-foreground mt-4 max-w-xs">
              No organizamos torneos. Creamos experiencias. Bienvenido al movimiento.
            </p>

            {/* Social Links */}
            <div className="flex gap-4 mt-6">
              {socialLinks.map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  whileHover={{ scale: 1.1 }}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((group) => (
            <div key={group.title}>
              <h4 className="font-[var(--font-display)] text-lg tracking-wide mb-4">{group.title}</h4>
              <ul className="space-y-3">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-muted-foreground hover:text-primary transition-colors text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">2025 COPA. Todos los derechos reservados.</p>
          <p className="text-sm text-muted-foreground">
            Hecho con <span className="text-primary">pasion</span> por la cultura deportiva.
          </p>
        </div>

        {/* Large background text */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 pointer-events-none overflow-hidden">
          <span className="font-[var(--font-display)] text-[20vw] leading-none text-secondary/30 whitespace-nowrap">
            COPA
          </span>
        </div>
      </div>
    </footer>
  )
}
