"use client"

import { motion } from "framer-motion"

const stats = [
  { value: "+50K", label: "ASISTENTES" },
  { value: "+120", label: "EVENTOS" },
  { value: "+1000", label: "JUGADORES" },
  { value: "+20", label: "MARCAS PARTNER" },
]

export function ImpactSection() {
  return (
    <section className="relative py-32 md:py-48 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-card" />
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

      {/* Large background text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
        <span className="font-[var(--font-display)] text-[30vw] leading-none text-secondary/20 whitespace-nowrap">
          IMPACTO
        </span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-primary font-medium tracking-widest text-sm">NUESTRO IMPACTO</span>
          <h2 className="font-[var(--font-display)] text-5xl md:text-7xl tracking-tight mt-4">
            LOS NUMEROS
            <br />
            <span className="text-primary">HABLAN</span>
          </h2>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <span className="font-[var(--font-display)] text-6xl md:text-8xl lg:text-9xl text-primary">
                {stat.value}
              </span>
              <p className="text-sm md:text-base text-muted-foreground mt-4 tracking-widest">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Bottom text */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.6 }}
          className="text-center text-muted-foreground text-lg mt-20 max-w-2xl mx-auto"
        >
          Desde 2019, hemos transformado la forma en que la gente vive el deporte amateur. 
          Esto es solo el principio.
        </motion.p>
      </div>
    </section>
  )
}
