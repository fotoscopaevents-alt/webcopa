"use client"

import { motion } from "framer-motion"
import { ArrowUpRight } from "lucide-react"

const sponsors = [
  { name: "Red Bull", tier: "platinum" },
  { name: "Estrella Damm", tier: "platinum" },
  { name: "Nocilla", tier: "gold" },
  { name: "ColaCao", tier: "gold" },
  { name: "Nestle", tier: "silver" },
  { name: "EF", tier: "silver" },
]

export function SponsorsSection() {
  return (
    <section className="relative py-32 md:py-48 overflow-hidden">
      <div className="absolute inset-0 bg-background" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-12 gap-16 items-start">
          {/* Left - Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-5"
          >
            <span className="text-primary font-medium tracking-widest text-sm">PARTNERS</span>
            <h2 className="font-[var(--font-display)] text-5xl md:text-7xl tracking-tight mt-4 mb-8 leading-[0.9]">
              MARCAS QUE
              <br />
              <span className="text-primary">CONFIAN</span>
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Las marcas mas importantes del sector ya forman parte de la familia COPA. 
              Juntos creamos experiencias unicas que conectan con la nueva generacion.
            </p>
            <a
              href="#contacto"
              className="inline-flex items-center gap-2 font-[var(--font-display)] text-lg tracking-wide text-primary hover:underline"
            >
              UNETE COMO PARTNER
              <ArrowUpRight className="w-5 h-5" />
            </a>
          </motion.div>

          {/* Right - Sponsors Grid */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-7"
          >
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {sponsors.map((sponsor, index) => (
                <motion.div
                  key={sponsor.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                  className="group"
                >
                  <div className="aspect-[3/2] bg-card border border-border flex items-center justify-center p-6 transition-all duration-300 hover:border-primary/50 hover:bg-secondary/50">
                    <span
                      className={`font-[var(--font-display)] text-xl md:text-2xl tracking-tight transition-colors ${
                        sponsor.tier === "platinum"
                          ? "text-primary"
                          : sponsor.tier === "gold"
                            ? "text-foreground"
                            : "text-muted-foreground"
                      } group-hover:text-primary`}
                    >
                      {sponsor.name.toUpperCase()}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Trust badge */}
            <div className="mt-8 p-6 bg-primary text-primary-foreground">
              <p className="font-[var(--font-display)] text-lg tracking-wide">
                &ldquo;COPA ha transformado como conectamos con la audiencia joven. Una colaboracion que marca la diferencia.&rdquo;
              </p>
              <span className="text-sm text-primary-foreground/70 mt-2 block">— Director de Marketing, Red Bull Espana</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
